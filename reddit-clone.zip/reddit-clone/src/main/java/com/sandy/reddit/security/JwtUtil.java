package com.sandy.reddit.security;

import java.time.Instant;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Service
public class JwtUtil {

	private String secret = "HelloMyNameIsShanawajMansuriIamGoodAtMyLearningAndMyJobDoWhateverYouWantGoToHell";
	
	@Value("${jwt.expiration.time}")
    private Long jwtExpirationInMillis;
	
	public String generateToken(Authentication authentication) {
		org.springframework.security.core.userdetails.User principal = (User) authentication.getPrincipal();
		
		return Jwts.builder().setSubject(principal.getUsername()).setIssuedAt(new Date(System.currentTimeMillis()))
				.setExpiration(new Date(System.currentTimeMillis() + 1000 * 60 * 60 * 10))
				.signWith(SignatureAlgorithm.HS256,secret).compact();
	}

	public boolean validateToken(String jwt) {
		Jwts.parser().setSigningKey(secret).parseClaimsJws(jwt);
		return true;
	}

	public String getUsernameFromJwt(String jwt) {
		Claims claims = Jwts.parser().setSigningKey(secret)
							.parseClaimsJws(jwt)
							.getBody();
		return claims.getSubject();
	}
	
	public String generateTokenWithUserName(String username) {
		return Jwts.builder().setSubject(username)
				.setIssuedAt(Date.from(Instant.now()))
				.signWith(SignatureAlgorithm.HS256, secret)
				.setExpiration(Date.from(Instant.now().plusMillis(jwtExpirationInMillis)))
				.compact();
	}
	
	public Long getJwtExpirationInMillis() {
        return jwtExpirationInMillis;
    }
	
}
