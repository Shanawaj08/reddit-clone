package com.sandy.reddit.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sandy.reddit.entity.Post;
import com.sandy.reddit.entity.User;
import com.sandy.reddit.entity.Vote;

@Repository
public interface VoteRepository extends JpaRepository<Vote, Integer> {

	Optional<Vote> findTopByPostAndUserOrderByVoteIdDesc(Post post, User currentUser);


}
