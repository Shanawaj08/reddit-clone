package com.sandy.reddit.service;

import java.time.Instant;
import java.util.Optional;
import java.util.UUID;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.sandy.reddit.DTO.AuthenticationResponse;
import com.sandy.reddit.DTO.LoginRequest;
import com.sandy.reddit.DTO.RefreshTokenRequest;
import com.sandy.reddit.DTO.RegisterRequest;
import com.sandy.reddit.config.AppConfig;
import com.sandy.reddit.entity.NotificationEmail;
import com.sandy.reddit.entity.User;
import com.sandy.reddit.entity.VerificationToken;
import com.sandy.reddit.exception.SpringRedditException;
import com.sandy.reddit.repository.UserRepository;
import com.sandy.reddit.repository.VerificationTokenRepository;
import com.sandy.reddit.security.JwtUtil;

//import com.sandy.reddit.security.JwtProvider;

@Service
public class AuthService {
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private VerificationTokenRepository verificationTokenRepo;
	
	@Autowired
	private  MailService mailService;
	
	@Autowired
	private AuthenticationManager authenticationManager;
	
	@Autowired
	private RefreshTokenService refreshTokenService;
	
	@Autowired
	private JwtUtil jwtUtil;
	
	@Autowired
	private AppConfig appConfig;
	
	/*public AuthService(PasswordEncoder passwordEncoder, UserRepository userRepo, 
			VerificationTokenRepository verificationTokenRepo, MailService mailService, 
			AuthenticationManager authenticationManager) {
		this.passwordEncoder = passwordEncoder;
		this.userRepo = userRepo;
		this.verificationTokenRepo = verificationTokenRepo;
		this.mailService = mailService;
		this.authenticationManager = authenticationManager;
	}*/

	@Transactional
	public void signup(RegisterRequest registerRequest) {
		User user = new User();
		user.setUserName(registerRequest.getUserName());
		user.setEmail(registerRequest.getEmail());
		user.setPassword(passwordEncoder.encode(registerRequest.getPassword()));
		user.setCreatedDate(Instant.now());
		user.setEnabled(false);
		userRepo.save(user);
		
		String token = generateVerficationToken(user);
		mailService.sendMail(new NotificationEmail("Please Activate your Account", user.getEmail(),
				"Thank you : " + appConfig.getUrl() + "/api/auth/accountVerification/" + token));
	}

	//below method will generate verficationToken and save to database for user verification
	private String generateVerficationToken(User user) {
		String token = UUID.randomUUID().toString();
		VerificationToken verificationToken = new VerificationToken();
		verificationToken.setToken(token);
		verificationToken.setUsers(user);
		verificationTokenRepo.save(verificationToken);
		return token;
	}

	public void verifyAccount(String token) {
		Optional<VerificationToken> verifyToken = verificationTokenRepo.findByToken(token);
		verifyToken.orElseThrow(() -> new SpringRedditException("Invalid Token"));
		fetchUserAndEnable(verifyToken.get());
	}

	@Transactional
	private void fetchUserAndEnable(VerificationToken verificationToken) {
		String username = verificationToken.getUsers().getUserName();
		User user = userRepo.findByUserName(username).orElseThrow(() -> new SpringRedditException("Cannot find User with Name " + username));
		user.setEnabled(true);
		userRepo.save(user);
	}

	public AuthenticationResponse login(LoginRequest loginRequest) {
		Authentication authenticate = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(loginRequest.getUserName(),
				loginRequest.getPassword()));
		SecurityContextHolder.getContext().setAuthentication(authenticate);
		String authtoken = jwtUtil.generateToken(authenticate);
		Instant expiresAt = Instant.now().plusMillis(jwtUtil.getJwtExpirationInMillis());
		String refreshToken = refreshTokenService.generateRefreshToken().getToken();
		return new AuthenticationResponse(authtoken, loginRequest.getUserName(), expiresAt, refreshToken);
		
	}
	public User getCurrentUser() {
		User username = new User();
		//org.springframework.security.core.userdetails.User principal = (org.springframework.security.core.userdetails.User) SecurityContextHolder
				//.getContext().getAuthentication().getPrincipal();
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (!(authentication instanceof AnonymousAuthenticationToken)) {
			username = userRepo.findByUserName(authentication.getName())
					.orElseThrow(() -> new UsernameNotFoundException("User Not found"));
			
		}
		return username;
	}

	public AuthenticationResponse refreshToken(RefreshTokenRequest refreshTokenRequest) {
		refreshTokenService.validateRefreshToken(refreshTokenRequest.getRefreshToken());
		String token = jwtUtil.generateTokenWithUserName(refreshTokenRequest.getUserName());
		Instant expiresAt = Instant.now().plusMillis(jwtUtil.getJwtExpirationInMillis());
		return new AuthenticationResponse(token, refreshTokenRequest.getUserName(), expiresAt, refreshTokenRequest.getRefreshToken());
	}

	public boolean isLoggedIn() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		return !(authentication instanceof AnonymousAuthenticationToken) && authentication.isAuthenticated();
	}

		
}
