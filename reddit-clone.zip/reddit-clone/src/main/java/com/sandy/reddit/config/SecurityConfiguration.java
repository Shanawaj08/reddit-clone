package com.sandy.reddit.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.sandy.reddit.security.JwtFilter;

@EnableWebSecurity  //enable the web security
public class SecurityConfiguration extends WebSecurityConfigurerAdapter{ /*WebSecurityConfigurerAdapter is base security class which provides us with all
 																			the basic security configurations and methods which we can override */
		@Autowired
		private UserDetailsService userDetailsService;
		
		@Autowired
		private JwtFilter jwtFilter;
		
		@Override
		protected void configure(HttpSecurity httpSecurity) throws Exception {
			//CustomerFilter customFilter = new CustomerFilter(authenticationManagerBean());
			//customFilter.setFilterProcessesUrl("/api/auth/login");
			/*CorsConfiguration corsConfiguration = new CorsConfiguration();
	        corsConfiguration.setAllowedHeaders(List.of("*"));
	        corsConfiguration.setAllowedOriginPatterns(List.of("*"));
	        corsConfiguration.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "PUT","OPTIONS","PATCH", "DELETE"));
	        corsConfiguration.setAllowCredentials(true);
	        corsConfiguration.setExposedHeaders(List.of("Authorization"));*/
	        
			httpSecurity.csrf().disable()
						.authorizeRequests()
						.antMatchers("/api/auth/login").permitAll()
						.antMatchers("/api/auth/**")
						.permitAll()
						.antMatchers(HttpMethod.GET, "/api/subreddit").hasAnyAuthority("USER")
						.antMatchers(HttpMethod.GET, "/api/posts").hasAnyAuthority("USER")
						.antMatchers("/v2/api-docs",
								"/configuration/ui",
								"/swagger-resources/**",
								"/configuration/security",
								"/spring-security-rest/swagger-ui.html",
								"/swagger-ui.html",
								"/swagger-ui/**",
								"/webjars/**")
						.permitAll()
						.anyRequest()
						.authenticated().and().exceptionHandling().and()
						.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
			
			//httpSecurity.addFilter(new CustomerFilter(authenticationManagerBean()));
			//httpSecurity.addFilterBefore(new CustomAuthorizationFilter(), UsernamePasswordAuthenticationFilter.class);
			httpSecurity.addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);
			httpSecurity.cors();
		}
		
		
		 @Override protected void configure(AuthenticationManagerBuilder auth) throws Exception 
		 { 
			 auth.userDetailsService(userDetailsService); 
		 }
		 
		
		@Bean
		PasswordEncoder passwordEncoder() {
			return new BCryptPasswordEncoder();
		}
		
		@Bean
		@Override
		public AuthenticationManager authenticationManagerBean() throws Exception {
			return super.authenticationManagerBean();
		}
		
	}
