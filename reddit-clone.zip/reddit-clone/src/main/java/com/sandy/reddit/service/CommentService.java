package com.sandy.reddit.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.sandy.reddit.DTO.CommentsDto;
import com.sandy.reddit.entity.Comment;
import com.sandy.reddit.entity.NotificationEmail;
import com.sandy.reddit.entity.Post;
import com.sandy.reddit.entity.User;
import com.sandy.reddit.exception.SpringRedditException;
import com.sandy.reddit.mapper.CommentMapper;
import com.sandy.reddit.repository.CommentRepository;
import com.sandy.reddit.repository.PostRepository;
import com.sandy.reddit.repository.UserRepository;

@Service
public class CommentService {
	
	private final PostRepository postRepo;
	
	private final UserRepository userRepo;
	
	private final AuthService authService;
	
	private final CommentMapper commentMapper;
	
	private final CommentRepository commentRepo;
	
	private final MailContentBuilder mailContentBuilder;
	
	private final MailService mailService;
	
	public CommentService(PostRepository postRepo, UserRepository userRepo, AuthService authService,
			CommentMapper commentMapper, CommentRepository commentRepo, MailContentBuilder mailContentBuilder,
			MailService mailService) {
		this.postRepo = postRepo;
		this.userRepo = userRepo;
		this.authService = authService;
		this.commentMapper = commentMapper;
		this.commentRepo = commentRepo;
		this.mailContentBuilder = mailContentBuilder;
		this.mailService = mailService;
	}

	public void saveComment(CommentsDto commentDto) {
		Post post = postRepo.findById(commentDto.getPostId())
				.orElseThrow(() -> new SpringRedditException("Not Found " + commentDto.getPostId()));
		Comment comment = commentMapper.map(commentDto, post, authService.getCurrentUser());
		commentRepo.save(comment);
		
		String message = mailContentBuilder.build(post.getUser().getUserName() + "Posted Comment on your Post" + post.getUrl());
		sendCommentNotification(message, post.getUser());
	}

	private void sendCommentNotification(String message, User user) {
		mailService.sendMail(new NotificationEmail(user.getUserName() + "Commented on your post", user.getEmail(), message));
		
	}
	
	public List<CommentsDto> getAllCommentsForPost(Integer postId) {
		Post post = postRepo.findById(postId)
				.orElseThrow(() -> new SpringRedditException("Not Found " + postId.toString()));
		return commentRepo.findByPost(post)
					.stream().map(commentMapper::mapToDto).collect(Collectors.toList());
		
	}

	public List<CommentsDto> getAllCommentsForUser(String userName) {
		User user = userRepo.findByUserName(userName)
				.orElseThrow(() -> new SpringRedditException("Not Found " + userName));
		return commentRepo.findAllByUser(user)
				.stream().map(commentMapper::mapToDto).collect(Collectors.toList());
		
	}

}
