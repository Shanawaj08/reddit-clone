package com.sandy.reddit.DTO;

import java.time.Instant;

public class AuthenticationResponse {

	private String authenticationToken;
	
	private String userName;
	
	private Instant expiresAt;
	
	private String refreshToken;

	public AuthenticationResponse() {
		
	}
	
	public AuthenticationResponse(String authenticationToken, String userName, Instant expiresAt, String refreshToken) {
		this.authenticationToken = authenticationToken;
		this.userName = userName;
		this.expiresAt = expiresAt;
		this.refreshToken = refreshToken;
	}

	public Instant getExpiresAt() {
		return expiresAt;
	}

	public void setExpiresAt(Instant expiresAt) {
		this.expiresAt = expiresAt;
	}

	public String getRefreshToken() {
		return refreshToken;
	}

	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}

	public String getAuthenticationToken() {
		return authenticationToken;
	}

	public void setAuthenticationToken(String authenticationToken) {
		this.authenticationToken = authenticationToken;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	
}
