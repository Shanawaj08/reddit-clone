package com.sandy.reddit.service;

import java.time.Instant;
import java.util.UUID;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sandy.reddit.entity.RefreshToken;
import com.sandy.reddit.exception.SpringRedditException;
import com.sandy.reddit.repository.RefreshTokenRepository;

@Service
@Transactional
public class RefreshTokenService {

	@Autowired
	private RefreshTokenRepository refreshTokenRepo;
	
	public RefreshToken generateRefreshToken() {
		RefreshToken refreshToken = new RefreshToken(UUID.randomUUID().toString(), Instant.now());
		
		return refreshTokenRepo.save(refreshToken);
	}
	
	public void validateRefreshToken(String token) {
		refreshTokenRepo.findByToken(token)
						.orElseThrow(() -> new SpringRedditException("Invalid Refresh Token"));
	}
	
	public void deleteRefreshToken(String token) {
		refreshTokenRepo.deleteByToken(token);
	}
}
