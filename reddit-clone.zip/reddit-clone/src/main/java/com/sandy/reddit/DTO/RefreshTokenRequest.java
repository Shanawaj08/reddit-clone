package com.sandy.reddit.DTO;

import javax.validation.constraints.NotBlank;

public class RefreshTokenRequest {

	@NotBlank
	private String refreshToken;
	
	private String userName;

	public RefreshTokenRequest() {
		
	}

	public RefreshTokenRequest(@NotBlank String refreshToken, String userName) {
		this.refreshToken = refreshToken;
		this.userName = userName;
	}

	public String getRefreshToken() {
		return refreshToken;
	}

	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	
	
}
