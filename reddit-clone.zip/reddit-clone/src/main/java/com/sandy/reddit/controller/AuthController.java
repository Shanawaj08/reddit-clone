package com.sandy.reddit.controller;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.fasterxml.jackson.core.exc.StreamWriteException;
import com.fasterxml.jackson.databind.DatabindException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sandy.reddit.DTO.AuthenticationResponse;
import com.sandy.reddit.DTO.LoginRequest;
import com.sandy.reddit.DTO.RefreshTokenRequest;
import com.sandy.reddit.DTO.RegisterRequest;
import com.sandy.reddit.repository.UserRepository;
import com.sandy.reddit.service.AuthService;
import com.sandy.reddit.service.RefreshTokenService;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "https://new-reddit-angular.herokuapp.com/")
public class AuthController {
	
	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private RefreshTokenService refreshTokenService;
	
	private final AuthService authService;
	
	public AuthController(AuthService authService) {
		this.authService = authService;
	}

	@PostMapping("/signup")
	public ResponseEntity<String> signup(@RequestBody RegisterRequest registerRequest) {
		authService.signup(registerRequest);
		return new ResponseEntity<>("User Registration Successful, Please Click on link sent to your"
				+ "Registered Email Id to Activate the Account", HttpStatus.OK);
	}
	
	@GetMapping("/accountVerification/{token}")
	public ResponseEntity<String> verifyAccount(@PathVariable("token") String token) {
		authService.verifyAccount(token);
		return new ResponseEntity<>("Account Activated Successfully", HttpStatus.OK);
	}
	
	@GetMapping("/refresh")
	public void refreshToken(HttpServletRequest request, HttpServletResponse response) throws StreamWriteException, DatabindException, IOException {
		String authorizationHeader = request.getHeader("Authorization");
		if(authorizationHeader != null && authorizationHeader.startsWith("Bearer ")) {
			
					try {
						String refresh_token = authorizationHeader.substring("Bearer ".length());
						Algorithm algo = Algorithm.HMAC256("secret".getBytes());
						JWTVerifier verifier = JWT.require(algo).build();
						DecodedJWT decodeJWT = verifier.verify(refresh_token);
						String userName = decodeJWT.getSubject();
						Optional<com.sandy.reddit.entity.User> user = userRepo.findByUserName(userName);
						String access_token = JWT.create().withSubject(user.get().getUserName())
								.withExpiresAt(new Date(System.currentTimeMillis() + 10*60*1000))
								.withIssuer(request.getRequestURL().toString())
								.withClaim("roles", "ROLE_USER")
								.sign(algo);
						Map<String, String> tokens = new HashMap<String, String>();
						tokens.put("access_token", access_token);
						tokens.put("refresh_token", refresh_token);
						response.setContentType(MediaType.APPLICATION_JSON_VALUE);
						new ObjectMapper().writeValue(response.getOutputStream(), tokens);
					} 
			
			catch(Exception e) {
				//throw new SpringRedditException("Not Authorize");
			}
			
		}else {
			throw new RuntimeException("Refresh Token Missing");
		}

	}
	
	@PostMapping("/logout")
	public ResponseEntity<String> logout(@Valid @RequestBody RefreshTokenRequest refreshTokenRequest) {
	    refreshTokenService.deleteRefreshToken(refreshTokenRequest.getRefreshToken());
	    return ResponseEntity.status(HttpStatus.OK).body("Refresh token Deleted Successfully");
	}
	
	@PostMapping("/login")
	public AuthenticationResponse login(@RequestBody LoginRequest loginRequest) {
		return authService.login(loginRequest);
	}
	
	@PostMapping("/refresh-token")
	public AuthenticationResponse refreshToken(@Valid @RequestBody RefreshTokenRequest refreshTokenRequest) {
		return authService.refreshToken(refreshTokenRequest);
	}
	
}
