package com.sandy.reddit.DTO;

import java.time.Instant;

public class CommentsDto {

	private Integer id;
	private Integer postId;
	private Instant createdDate;
	private String text;
	private String userName;
	
	public CommentsDto() {
		
	}

	public CommentsDto(Integer postId, Instant createdDate, String text, String userName) {
		this.postId = postId;
		this.createdDate = createdDate;
		this.text = text;
		this.userName = userName;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getPostId() {
		return postId;
	}

	public void setPostId(Integer postId) {
		this.postId = postId;
	}

	public Instant getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Instant createdDate) {
		this.createdDate = createdDate;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	
}
