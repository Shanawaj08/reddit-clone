package com.sandy.reddit.service;


import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.sandy.reddit.DTO.PostRequest;
import com.sandy.reddit.DTO.PostResponse;
import com.sandy.reddit.entity.Post;
import com.sandy.reddit.entity.Subreddit;
import com.sandy.reddit.entity.User;
import com.sandy.reddit.exception.SpringRedditException;
import com.sandy.reddit.mapper.PostMapper;
import com.sandy.reddit.repository.PostRepository;
import com.sandy.reddit.repository.SubredditRepository;
import com.sandy.reddit.repository.UserRepository;

@Service
public class PostService {

	private final SubredditRepository subredditRepo;
	
	private final AuthService authService;
	
	private final PostMapper postMapper;
	
	private final PostRepository postRepo;
	
	private final UserRepository userRepo;
	
	
	
	public PostService(SubredditRepository subredditRepo, AuthService authService, PostMapper postMapper, PostRepository postRepo,
			UserRepository userRepo) {
		this.subredditRepo = subredditRepo;
		this.authService = authService;
		this.postMapper = postMapper;
		this.postRepo = postRepo;
		this.userRepo = userRepo;
	}

	public Post savePost(PostRequest postRequest) {
		Subreddit subreddit = subredditRepo.findByName(postRequest.getSubredditName())
					.orElseThrow(() -> new SpringRedditException("Not Found"));
		User currentUser = authService.getCurrentUser();
		return postRepo.save(postMapper.map(postRequest, subreddit, currentUser));

	}
	

	public PostResponse getPostById(int id) {
		Post post = postRepo.findById(id)
				.orElseThrow(() -> new SpringRedditException("Not Found"));
		return postMapper.mapToDto(post);
	}

	public List<PostResponse> getAllPosts() {
		return postRepo.findAll()
				.stream()
				.map(postMapper::mapToDto)
				.collect(Collectors.toList());
	}

	public List<PostResponse> getPostBySubreddit(int id) {
		Subreddit subreddit = subredditRepo.findById(id)
				.orElseThrow(() -> new SpringRedditException("Not Found"));
		List<Post> posts = postRepo.findAllBySubreddit(subreddit);
		return posts.stream().map(postMapper::mapToDto).collect(Collectors.toList());
	}

	public List<PostResponse> getPostByUsername(String name) {
		User user = userRepo.findByUserName(name)
				.orElseThrow(() -> new SpringRedditException("Not Found"));
		List<Post> posts = postRepo.findByUser(user);
		return posts.stream().map(postMapper::mapToDto).collect(Collectors.toList());
	}

	
}
