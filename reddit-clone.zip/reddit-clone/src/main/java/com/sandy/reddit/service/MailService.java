package com.sandy.reddit.service;

import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.sandy.reddit.entity.NotificationEmail;
import com.sandy.reddit.exception.SpringRedditException;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MailService {
	
	
	private final JavaMailSender mailSender;
	
	private final MailContentBuilder mailBuilder;
	
	public MailService(JavaMailSender mailSender, MailContentBuilder mailBuilder) {
		this.mailSender = mailSender;
		this.mailBuilder = mailBuilder;
	}

	@Async
	public void sendMail(NotificationEmail notificationEmail) {
		MimeMessagePreparator messagePreparator = mimeMessage -> {
			MimeMessageHelper messageHelper = new MimeMessageHelper(mimeMessage);
			messageHelper.setFrom("mansurishanawaj8@gmail.com");
			messageHelper.setTo(notificationEmail.getRecipient());
			messageHelper.setSubject(notificationEmail.getSubject());
			messageHelper.setText(mailBuilder.build(notificationEmail.getBody()));
		};
		try {
			mailSender.send(messagePreparator);
		}
		catch(MailException e) {
			throw new SpringRedditException("Exception Occurred when sending Mail !!");
		}
		
		
	}

}
