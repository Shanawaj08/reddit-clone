package com.sandy.reddit.service;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.sandy.reddit.DTO.VoteDto;
import com.sandy.reddit.entity.Post;
import com.sandy.reddit.entity.Vote;
import com.sandy.reddit.entity.VoteType;
import com.sandy.reddit.exception.SpringRedditException;
import com.sandy.reddit.repository.PostRepository;
import com.sandy.reddit.repository.VoteRepository;

@Service
public class VoteService {

	private final PostRepository postRepo;
	private final VoteRepository voteRepo;
	private final AuthService authService;
	
	public VoteService(PostRepository postRepo, VoteRepository voteRepo, AuthService authService) {
		this.postRepo = postRepo;
		this.voteRepo = voteRepo;
		this.authService = authService;
	}

	
	public void vote(VoteDto voteDto) {
		Post post = postRepo.findById(voteDto.getPostId())
				.orElseThrow(() -> new SpringRedditException("Post Not Found with Id : " + voteDto.getPostId()));
		Optional<Vote> voteByPostAndUser = voteRepo.findTopByPostAndUserOrderByVoteIdDesc(post,authService.getCurrentUser());
		if(voteByPostAndUser.isPresent() && voteByPostAndUser.get().getVoteType()
				.equals(voteDto.getVoteType())) {
			throw new SpringRedditException("You have Already " + voteDto.getVoteType() + "'d for this Post");
		}
		if(post.getVoteCount() == null) post.setVoteCount(0);
		if(VoteType.UPVOTE.equals(voteDto.getVoteType())) {
			post.setVoteCount(post.getVoteCount()+1);
		}
		else {
			post.setVoteCount(post.getVoteCount()-1);
		}
		voteRepo.save(mapToVote(voteDto, post));
		postRepo.save(post);
		
	}
	
	private Vote mapToVote(VoteDto voteDto, Post post) {
		Vote vote = new Vote();
		vote.setVoteType(voteDto.getVoteType());
		vote.setPost(post);
		vote.setUser(authService.getCurrentUser());
		return vote;
	}

}
