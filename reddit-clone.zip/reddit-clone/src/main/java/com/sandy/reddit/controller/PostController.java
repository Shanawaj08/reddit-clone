package com.sandy.reddit.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sandy.reddit.DTO.PostRequest;
import com.sandy.reddit.DTO.PostResponse;
import com.sandy.reddit.entity.User;
import com.sandy.reddit.service.AuthService;
import com.sandy.reddit.service.PostService;

@RestController
@RequestMapping("/api/posts")
public class PostController {

	@Autowired
	private AuthService authService;

	private final PostService postService;

	public PostController(PostService postService) {
		this.postService = postService;
	}

	@PostMapping
	public ResponseEntity<Void> createPost(@RequestBody PostRequest postRequest) {
		postService.savePost(postRequest);
		return new ResponseEntity<Void>(HttpStatus.CREATED);
	}

	@GetMapping("/{id}")
	public ResponseEntity<PostResponse> getPost(@PathVariable("id") int id) {
		return ResponseEntity.status(HttpStatus.OK).body(postService.getPostById(id));
	}

	@GetMapping
	public ResponseEntity<List<PostResponse>> getAllPosts() {
		return ResponseEntity.status(HttpStatus.OK).body(postService.getAllPosts());
	}

	@GetMapping("/by-subreddit/{id}")
	public ResponseEntity<List<PostResponse>> getPostBySubreddit(@PathVariable("id") int id) {
		return ResponseEntity.status(HttpStatus.OK).body(postService.getPostBySubreddit(id));
	}

	@GetMapping("/by-user/{name}")
	public ResponseEntity<List<PostResponse>> getPostByUsername(@PathVariable("name") String name) {
		return ResponseEntity.status(HttpStatus.OK).body(postService.getPostByUsername(name));
	}

	@GetMapping("/users")
	public User displayUser() {
		return authService.getCurrentUser();
	}
}
