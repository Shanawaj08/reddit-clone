package com.sandy.reddit.DTO;

import com.sandy.reddit.entity.VoteType;

public class VoteDto {
	
	private VoteType voteType;
	private Integer postId;
	
	public VoteDto() {
		
	}

	public VoteDto(VoteType voteType, Integer postId) {
		this.voteType = voteType;
		this.postId = postId;
	}

	public VoteType getVoteType() {
		return voteType;
	}

	public void setVoteType(VoteType voteType) {
		this.voteType = voteType;
	}

	public Integer getPostId() {
		return postId;
	}

	public void setPostId(Integer postId) {
		this.postId = postId;
	}
	
	

}
