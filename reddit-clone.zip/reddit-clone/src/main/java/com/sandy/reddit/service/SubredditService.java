package com.sandy.reddit.service;

import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.sandy.reddit.DTO.SubredditDto;
import com.sandy.reddit.entity.Subreddit;
import com.sandy.reddit.exception.SpringRedditException;
import com.sandy.reddit.mapper.SubredditMapper;
import com.sandy.reddit.repository.SubredditRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class SubredditService {

	private final SubredditRepository subredditRepo;
	
	private final SubredditMapper subredditMapper;

	public SubredditService(SubredditRepository subredditRepo, SubredditMapper subredditMapper) {
		super();
		this.subredditRepo = subredditRepo;
		this.subredditMapper = subredditMapper;
	}

	@Transactional
	public SubredditDto saveSubreddit(SubredditDto subredditDto) {
		Subreddit subreddit = subredditRepo.save(subredditMapper.mapDtoToSubreddit(subredditDto));
		subredditDto.setId(subreddit.getId());
		return subredditDto;
	}

	/*
	 * private Subreddit mapSubredditDto(SubredditDto subredditDto) { Subreddit
	 * subreddit = new Subreddit();
	 * subreddit.setName(subredditDto.getSubredditName());
	 * subreddit.setDescription(subredditDto.getDescription()); return subreddit;
	 * 
	 * }
	 */

	@Transactional
	public List<SubredditDto> getAll() {
		return subredditRepo.findAll()
				.stream()
				.map(subredditMapper::mapSubredditToDto)
				.collect(Collectors.toList());
				    
		
	}
	
	/*
	 * private SubredditDto mapToDto(Subreddit subreddit) { SubredditDto
	 * subredditDto = new SubredditDto();
	 * subredditDto.setSubredditName(subreddit.getName());
	 * subredditDto.setId(subreddit.getId());
	 * subredditDto.setNoOfPosts(subreddit.getPosts().size()); return subredditDto;
	 * }
	 */

	public SubredditDto getSubredditById(int id) {
		Subreddit subreddit = subredditRepo.findById(id)
				.orElseThrow(() -> new SpringRedditException("Subreddit Not Found With Id : "+ id));
		return subredditMapper.mapSubredditToDto(subreddit);
	}
}
