package com.sandy.reddit.entity;

import java.util.Arrays;

import com.sandy.reddit.exception.SpringRedditException;

public enum VoteType {
	
	UPVOTE(1), DOWNVOTE(-1);

	public int direction;
	
	VoteType(int direction) {
		this.direction = direction;
	}
	
	public static VoteType lookup(Integer direction) {
		return Arrays.stream(VoteType.values())
				.filter(value -> value.getDirection().equals(direction))
				.findAny()
				.orElseThrow(() -> new SpringRedditException("Vote Not Found"));
	}

	public Integer getDirection() {
		return this.direction;
	}

}
